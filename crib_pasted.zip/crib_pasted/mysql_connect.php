<?php
$user = "u556432116_crib";
$password = "jonny555";
$host = "mysql.1freehosting.com";
mysql_connect($host,$user,$password);
mysql_select_db("u556432116_crib");
?>