<?php
mysql_connect("mysql.1freehosting.com","u556432116_test","jonny555") or die("Ne�lo se p�ipojit k DB.");
mysql_select_db("u556432116_test") or die("Ne�lo se p�ipojit k DB.");
?>